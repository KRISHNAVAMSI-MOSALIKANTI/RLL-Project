package com;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
public class EMedicareAppTest {
	WebDriver driver=null;
	@BeforeTest(groups= {"admin","user"})
	public void beforetest()
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\HP\\Downloads\\selenium jar files\\chromedriver.exe");	
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://localhost:4200/home");
		driver.manage().window().maximize();
	}
	@Test(priority=1,groups= {"admin"})
	public void adminLoginTest() throws InterruptedException
	{
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("/html/body/app-root/app-homepage/nav/div/div/ul/li[1]/a")).click();
		driver.findElement(By.id("form2Example17")).sendKeys("admin@gmail.com");
		driver.findElement(By.id("form2Example27")).sendKeys("admin");
	    driver.findElement(By.xpath("/html/body/app-root/app-login/section/div/div/div/div/div/div[2]/div/form/input[1]")).click();
	    driver.findElement(By.xpath("/html/body/app-root/app-login/section/div/div/div/div/div/div[2]/div/form/div[4]/button[1]")).click();
	}
	@Test(priority=2,groups= {"admin"})
	public void updateProduct() throws InterruptedException
	{
		Thread.sleep(2000);		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		//driver.findElement(By.xpath("/html/body/app-root/app-admindashboard/header/nav/ul/li[1]/a")).click();				
		 JavascriptExecutor js=(JavascriptExecutor)driver;
	     js.executeScript("window.scrollBy(0,800)");
	     Thread.sleep(2000);
		  driver.findElement(By.xpath("/html/body/app-root/app-admindashboard/div/app-admin-product-retrieve/div/div/div/div[4]/div/div/input[1]")).click();
		 js.executeScript("window.scrollBy(0,-800)");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("/html/body/app-root/app-admindashboard/div/app-admin-product-retrieve/div/div[1]/div/form/div[2]/input")).clear();		
		driver.findElement(By.xpath("/html/body/app-root/app-admindashboard/div/app-admin-product-retrieve/div/div[1]/div/form/div[2]/input")).sendKeys("950");
		Thread.sleep(3000);
		 JavascriptExecutor jsnew=(JavascriptExecutor)driver;
		 jsnew.executeScript("window.scrollBy(0,650)");
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/app-root/app-admindashboard/div/app-admin-product-retrieve/div/div[1]/div/form/div[6]/button[1]")).click();
		 js.executeScript("window.scrollBy(0,-350)");		
	}	
	@Test(priority=3,groups= {"admin"})
	public void addProductTest() throws InterruptedException
	{
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("/html/body/app-root/app-admindashboard/header/nav/ul/li[2]/a")).click();
		driver.findElement(By.xpath("/html/body/app-root/app-admindashboard/div/app-add-product/div/form/div[1]/input")).sendKeys("Cough Syrup");
		driver.findElement(By.xpath("/html/body/app-root/app-admindashboard/div/app-add-product/div/form/div[2]/input")).sendKeys("70");
		driver.findElement(By.xpath("/html/body/app-root/app-admindashboard/div/app-add-product/div/form/div[3]/input")).sendKeys("https://images.apollo247.in/pub/media/catalog/product/G/E/GEL0002_3_1.jpg");
		WebElement dropdownElement = driver.findElement(By.xpath("/html/body/app-root/app-admindashboard/div/app-add-product/div/form/div[4]/select"));
	    Select select = new Select(dropdownElement);
        select.selectByVisibleText("Tablet");
        driver.findElement(By.xpath("/html/body/app-root/app-admindashboard/div/app-add-product/div/form/div[5]/input")).sendKeys("Acidity Tablet");
        JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
        Thread.sleep(5000);
        driver.findElement(By.xpath("/html/body/app-root/app-admindashboard/div/app-add-product/div/form/div[6]/button[1]")).click();
        JavascriptExecutor js1=(JavascriptExecutor)driver;
		js1.executeScript("window.scrollBy(0,-600)");
		Thread.sleep(3000);		
		//driver.findElement(By.xpath("/html/body/app-root/app-admindashboard/header/nav/ul/li[1]/a")).click();		
	}	
	@Test(priority=4,dependsOnMethods= {"updateProduct"},groups= {"admin"})
	public void deleteProduct() throws InterruptedException
	{
		 Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("/html/body/app-root/app-admindashboard/header/nav/ul/li[1]/a")).click();
		JavascriptExecutor js1=(JavascriptExecutor)driver;
		js1.executeScript("window.scrollBy(0,700)");
	    Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/app-root/app-admindashboard/div/app-admin-product-retrieve/div/div/div/div[2]/div/div/input[2]")).click();
		Thread.sleep(3000);
		js1.executeScript("window.scrollBy(0,-500)");
		Thread.sleep(3000);
		 driver.findElement(By.xpath("/html/body/app-root/app-admindashboard/header/nav/ul/li[3]/a")).click();
	}	
	@Test(priority=5,dependsOnMethods= {"deleteProduct"},groups= {"admin"})
	public void viewUsers() throws InterruptedException
	{
	  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	  driver.findElement(By.xpath("/html/body/app-root/app-admindashboard/header/nav/ul/li[3]/a")).click();
	  driver.findElement(By.xpath("/html/body/app-root/app-admindashboard/div/app-viewuser/div/div/table/tr[3]/td[3]/input")).click();
	  Thread.sleep(3000);	  
	}	
	@Test(priority=6,dependsOnMethods= {"viewUsers"},groups= {"admin"})
	public void updateAdminPwd() throws InterruptedException
	{
		 Thread.sleep(5000);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("/html/body/app-root/app-admindashboard/header/nav/ul/li[4]/a")).click();
		driver.findElement(By.xpath("/html/body/app-root/app-change-password/section/div/div/div/div/div/div[2]/div/form/div[2]/input")).sendKeys("admin@gmail.com");
		driver.findElement(By.xpath("/html/body/app-root/app-change-password/section/div/div/div/div/div/div[2]/div/form/div[3]/input")).sendKeys("admin456");
		driver.findElement(By.xpath("/html/body/app-root/app-change-password/section/div/div/div/div/div/div[2]/div/form/div[4]/button[1]")).click();
		driver.findElement(By.xpath("/html/body/app-root/app-change-password/section/div/div/div/div/div/div[2]/div/form/button")).click();
	}	
	@Test(priority=7,groups= {"user"})
	public void userLoginTest()
	{
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("/html/body/app-root/app-homepage/nav/div/div/ul/li[1]/a")).click();
		driver.findElement(By.id("form2Example17")).sendKeys("kiran@gmail.com");
		driver.findElement(By.id("form2Example27")).sendKeys("abc");
	    driver.findElement(By.xpath("/html/body/app-root/app-login/section/div/div/div/div/div/div[2]/div/form/input[2]")).click();
	    driver.findElement(By.xpath("/html/body/app-root/app-login/section/div/div/div/div/div/div[2]/div/form/div[4]/button[1]")).click();
	}	
	@Test(priority=8,groups= {"user"})
	public void addTocardTest() throws InterruptedException
	{
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("/html/body/app-root/app-userdashboard/div/div[3]/div[1]/div/div/div/div[2]/div/div/button")).click();
		driver.findElement(By.xpath("/html/body/app-root/app-userdashboard/div/div[3]/div[2]/div/div/div/div[2]/div/div/button")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("/html/body/app-root/app-userdashboard/div/div[1]/span/button")).click();
	}
	@Test(priority=9,groups= {"user"})
	public void checkoutTest() throws InterruptedException
	{
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(5000);
		driver.findElement(By.xpath("/html/body/app-root/app-cart/div/div/div/table/tbody/tr[3]/td[4]/button")).click();
	}
	@Test(priority=10,groups= {"user"})
	public void billingTest() throws InterruptedException
	{
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("/html/body/app-root/app-billing/div/div/div/form/input[1]")).sendKeys("abc");
		driver.findElement(By.xpath("/html/body/app-root/app-billing/div/div/div/form/input[2]")).sendKeys("abc");
		driver.findElement(By.xpath("/html/body/app-root/app-billing/div/div/div/form/input[3]")).sendKeys("abc");
		driver.findElement(By.xpath("/html/body/app-root/app-billing/div/div/div/form/input[4]")).sendKeys("abc");
		driver.findElement(By.xpath("/html/body/app-root/app-billing/div/div/div/form/div/div[2]/input")).sendKeys("605010");
		driver.findElement(By.xpath("/html/body/app-root/app-billing/div/div/div/form/div/div[1]/input")).sendKeys("abc");
		Thread.sleep(5000);
		driver.findElement(By.xpath("/html/body/app-root/app-billing/div/div/div/form/button")).click();
	}
	@Test(priority=11,groups= {"user"})
	public void paymentTest() throws InterruptedException
	{
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("/html/body/app-root/app-checkout/div/div/div/form/input[1]")).sendKeys("abc");
		driver.findElement(By.xpath("/html/body/app-root/app-checkout/div/div/div/form/input[2]")).sendKeys("2134 5487 2135 4585");
		driver.findElement(By.xpath("/html/body/app-root/app-checkout/div/div/div/form/input[3]")).sendKeys("6");
		driver.findElement(By.xpath("/html/body/app-root/app-checkout/div/div/div/form/div[2]/div[2]/input")).sendKeys("789");
		driver.findElement(By.xpath("/html/body/app-root/app-checkout/div/div/div/form/div[2]/div[1]/input")).sendKeys("2024");
		Thread.sleep(5000);
	    driver.findElement(By.xpath("/html/body/app-root/app-checkout/div/div/div/form/button")).click();		
	}
	@Test(priority=12,groups= {"user"})
	public void paymentSuccessTest() throws InterruptedException
	{
		Thread.sleep(5000);
		Alert alert=driver.switchTo().alert();
		alert.accept();		
	}	
	@Test(priority=13,groups= {"user"})
	public void changeUserPwd()
	{
		driver.get("http://localhost:4200/home");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("/html/body/app-root/app-homepage/nav/div/div/ul/li[1]/a")).click();
		driver.findElement(By.id("form2Example17")).sendKeys("kiran@gmail.com");
		driver.findElement(By.id("form2Example27")).sendKeys("abc");
	    driver.findElement(By.xpath("/html/body/app-root/app-login/section/div/div/div/div/div/div[2]/div/form/input[2]")).click();
	    driver.findElement(By.xpath("/html/body/app-root/app-login/section/div/div/div/div/div/div[2]/div/form/div[4]/button[1]")).click();	    
	    driver.findElement(By.xpath("/html/body/app-root/app-userdashboard/div/header/nav/ul/li[1]/a")).click();	    
	    driver.findElement(By.xpath("/html/body/app-root/app-change-password/section/div/div/div/div/div/div[2]/div/form/div[2]/input")).sendKeys("kiran@gmail.com");
	    driver.findElement(By.xpath("/html/body/app-root/app-change-password/section/div/div/div/div/div/div[2]/div/form/div[3]/input")).sendKeys("abc");
	    driver.findElement(By.xpath("/html/body/app-root/app-change-password/section/div/div/div/div/div/div[2]/div/form/div[4]/button[1]")).click();	    
	}
	@AfterTest()
	public void aftertest()
	{
		//driver.close();
	}	
}